<?php
$currentPage = 'cart';
require 'header.php';
?>
<div class="row">
    <div class="sidebar-left sidebar">
        <p></p>
    </div>
    <div class="main">
        <table>
            <caption>Megrendelt Mácskák:</caption>
            <thead>
                <tr>
                    <th id="tipus">Típus</th>
                    <th id="mdat">Megrendelés Dátuma</th>
                </tr>

            </thead>
            <tbody>
                <tr>
                    <td headers="tipus">Kicsi, elsőféle, alap</td>
                    <td headers="mdat">2000.05.24.</td>
                </tr>
            </tbody>
        </table>

    </div>
    <div class="sidebar-right sidebar">
        <p></p>
    </div>
</div>

<footer class="footer">
    <div>
        <div class="fTable">
            <div class="fRow">
                <img width="90" src="img/cats.png" class="logo" alt="logo" />
            </div>
            <div class="fRow">
                <div class="fCell">
                    <h4>A cégről</h4>
                    <section><p>tel.: 06701234567</p><p>1088, Budapest, utca 18.</p>
                        <p>faller.daniel3@gmail.com</p></section>
                </div>
                <div class="fCell">
                    <h4>Nyitvatartás:</h4>
                    <section>
                        <p>h:10-14</p>
                        <p>k:10-14</p>
                        <p>sz:10-14</p>
                        <p>cs:10-14</p>
                    </section>
                </div>
                <div class="fCell">
                    <h4>Iratkozz fel most</h4>
                    <section><p>Feliratkozom a hírlevélre (am ez is lehet link akar)</p></section>
                </div>
            </div>
        </div>
    </div>
</footer>


</body>
</html>