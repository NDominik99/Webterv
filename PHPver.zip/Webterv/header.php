<?php
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Webterv</title>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=2'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/main.css'>
</head>
<body>
<div class="header">
    <img src="img/cats.png" class="logo" alt="logo" />
    <img src="img/yarn.png" class="yarn" alt="cérna" />
    <h1>Macska gyártó cég</h1>
</div>

<nav id="menu">
    <header><h3>Belépés</h3></header>
    <ul>
        <li><a href="bejelent.php">Bejelentkezés</a></li>
        <li><a href="reg.php">Regisztráció</a></li>
    </ul>
</nav>

<section>
    <div class="navbar">
        <a <?php echo ($currentPage == 'index') ? 'class="current"' : '';?> href="index.php">Főoldal</>
        <a <?php echo ($currentPage == 'about') ? 'class="current"' : '';?> href="elerhet.php">Kapcsolat</a>
        <div  <?php echo ($currentPage == 'small' || $currentPage == 'med' || $currentPage == 'big') ? 'class="dropdown current"' : 'class="dropdown"';?>>
            <button class="dropbtn">Macskák
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a <?php echo ($currentPage == 'small') ? 'class="current"' : '';?> href="kismacska.php">Kicsi</a>
                <a <?php echo ($currentPage == 'med') ? 'class="current"' : '';?> href="kozepes.php">Közepes</a>
                <a <?php echo ($currentPage == 'big') ? 'class="current"' : '';?> href="nagymacska.php">Nagy</a>
            </div>
        </div>
        <div <?php echo ($currentPage == 'login' || $currentPage == 'signup') ? 'class="dropdown current"' : 'class="dropdown"';?>>
            <button class="dropbtn">Felhasználók
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a <?php echo ($currentPage == 'login') ? 'class="current"' : '';?> href="bejelent.php">Bejelentkezés</a>
                <a <?php echo ($currentPage == 'signup') ? 'class="current"' : '';?> href="reg.php">Regisztráció</a>
            </div>
        </div>
        <a <?php echo ($currentPage == 'cart') ? 'class="current"' : '';?> href="kosár.php">Megrendelések</a>
    </div>
</section>

