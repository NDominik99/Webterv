<?php
    $currentPage="index";
    require 'header.php';
?>
    <div class="row">
        <div class="sidebar-left sidebar">
            <p></p>
        </div>
        <div class="main">
            <h1>Hiányzik egy kis macska a kanapéjáról?</h1>
            <br>
            <br>

            <h2> Ha igen, nem hagyunk magadra. Rendelj tőlünk És pár napon belül kiszállítjuk.
                Maximum 3 napos, garantált határidővel javítjuk bármilyen típusú panaszod.</h2>
            <br>
            <br>

            <h2>Ha nem lesz kész a macskád a megbeszélt időre, naponta 10%-ot engedünk az árából.”</h2>


        </div>
        <div class="sidebar-right sidebar">
            <p></p>
        </div>
    </div>

    <footer class="footer">
        <div>
        <div class="fTable">
            <div class="fRow">
                <img width="90" src="img/cats.png" class="logo" alt="logo" />
            </div>
            <div class="fRow">
                <div class="fCell">
                    <h4>A cégről</h4>
                    <section><p>tel.: 06701234567</p><p>1088, Budapest, utca 18.</p>
                    <p>faller.daniel3@gmail.com</p></section>
                </div>
                <div class="fCell">
                    <h4>Nyitvatartás:</h4>
                    <section>
                        <p>h:10-14</p>
                        <p>k:10-14</p>
                        <p>sz:10-14</p>
                        <p>cs:10-14</p>
                    </section>
                </div>
                <div class="fCell">
                    <h4>Iratkozz fel most</h4>
                    <section><p>Feliratkozom a hírlevélre (am ez is lehet link akar)</p></section>
                </div>
            </div>
        </div>
        </div>
    </footer>


</body>
</html>