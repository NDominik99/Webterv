<?php
$currentPage = 'about';
require 'header.php';
?>

<div class="row">
    <div id="jobboldal" class="sidebar-left sidebar">
        <p>some text or img</p>
    </div>
    <div id="kapcs" class="main">
        <h2>Kapcsolat</h2>
        <section>
            <div><h3>Személyesen:</h3><a href="https://www.google.com/maps/place/45%C2%B031'26.0%22N+24%C2%B059'17.3%22W/@45.5238787,-24.9903137,17z/data=!3m1!4b1!4m6!3m5!1s0x0:0x0!7e2!8m2!3d45.5238749!4d-24.988125" target="_blank"><p>1088, Budapest, utca 18.</p></a></div>
            <div><h3>Elérhetőségeink</h3>
                <section><p>tel.: 06701234567</p>
                <a href="mailto:faller.daniel3@gmail.com">faller.daniel3@gmail.com</a></section></div>
        </section>
    </div>
    <div id="baloldal" class="sidebar-right sidebar">
        <p>ez lehet nem kell nemtom</p>
    </div>
</div>

<div id="also" class="footer">
    <div class="fTable">
        <div class="fRow">
            <img width="90" src="img/cats.png" class="logo" alt="logo" />
        </div>
        <div class="fRow">
            <div id="footelerh" class="fCell">
                <h4>Elérhetőségek</h4>
                <section><p>tel.: 06701234567</p><p>1088, Budapest, utca 18.</p>
                <p>faller.daniel3@gmail.com</p></section>
            </div>
            <div id="nyitv" class="fCell">
                <h4>Nyitvatartás:</h4>
                <section>
                    <p>h:10-14</p>
                    <p>k:10-14</p>
                    <p>sz:10-14</p>
                    <p>cs:10-14</p>
                </section>
            </div>
            <div id="footfelir" class="fCell">
                <h4>Iratkozz fel most</h4>
                <section><p>Feliratkozom a hírlevélre (am ez is lehet link akar)</p></section>
            </div>
        </div>
    </div>

</div>


</body>
</html>