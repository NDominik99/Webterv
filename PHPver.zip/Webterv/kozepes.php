<?php
$currentPage = 'med';
require 'header.php';
?>

<div class="row">
    <div class="sidebar-left sidebar">
        <p></p>
    </div>
    <div class="main">
        <h1>Kismacska</h1>
        <section><p>leírás</p></section>
        <hr/>
        <table id="osszeh">
            <caption id="cím">Termék összefoglaló</caption>

            <thead>
            <tr>
                <th id="tul">Features</th>
                <th id="alap">Alap</th>
                <th id="fejl">Feljett</th>
                <th id="hip">Hiperszuper</th>
                <th id="szor"></th>
                <th id="dorombolas"></th>
                <th id="kedves"></th>
                <th id="szobatiszta"></th>
                <th id="ar"></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td headers="tul">Szőr</td>
                <td headers="alap szor">Van</td>
                <td headers="fejl szor">Van</td>
                <td headers="hip szor">Van</td>
            </tr>
            <tr>
                <td headers="tul">Dorombolás</td>
                <td headers="alap dorombolas">Van</td>
                <td headers="fejl dorombolas">Van</td>
                <td headers="hip dorombolas">Van</td>
            </tr>
            <tr>
                <td headers="tul">Kedves</td>
                <td headers="alap kedves">Nincs</td>
                <td headers="fejl kedves">Van</td>
                <td headers="hip kedves">Van</td>
            </tr>
            <tr>
                <td headers="tul">Szobatiszta</td>
                <td headers="alap szobatiszta">Nincs</td>
                <td headers="fejl szobatiszta">Nincs</td>
                <td headers="hip szobatiszta">Van</td>
            </tr>
            <tr>
                <td headers="tul">Ár</td>
                <td headers="alap ar">1000 Ft</td>
                <td headers="fejl ar">5000 Ft</td>
                <td headers="hip ar">10000 Ft</td>
            </tr>
            </tbody>
        </table>
        <p>Fajta 1</p>
        <img src="img/medium1.jpg" class="product" alt="medium1" />
        <fieldset class="rating one">
            <input type="radio" id="star5" name="rating" value="5" /><label for="star5" title="Szuper"><span>&#9733;</span></label>
            <input type="radio" id="star4" name="rating" value="4" /><label for="star4" title="Jó"><span>&#9733;</span></label>
            <input type="radio" id="star3" name="rating" value="3" /><label for="star3" title="Meh"><span>&#9733;</span></label>
            <input type="radio" id="star2" name="rating" value="2" /><label for="star2" title="Rossz"><span>&#9733;</span></label>
            <input type="radio" id="star1" name="rating" value="1" /><label for="star1" title="Borzalmas"><span>&#9733;</span></label>
        </fieldset>
        <p>Fajta 2</p>
        <img src="img/medium2.jpg" class="product" alt="medium2" />
        <fieldset class="rating two">
            <input type="radio" id="star5-1" name="ratingtwo" value="5" /><label for="star5-1" title="Szuper"><span>&#9733;</span></label>
            <input type="radio" id="star4-1" name="ratingtwo" value="4" /><label for="star4-1" title="Jó"><span>&#9733;</span></label>
            <input type="radio" id="star3-1" name="ratingtwo" value="3" /><label for="star3-1" title="Meh"><span>&#9733;</span></label>
            <input type="radio" id="star2-1" name="ratingtwo" value="2" /><label for="star2-1" title="Rossz"><span>&#9733;</span></label>
            <input type="radio" id="star1-1" name="ratingtwo" value="1" /><label for="star1-1" title="Borzalmas"><span>&#9733;</span></label>
        </fieldset>
        <p>Fajta 3</p>
        <img src="img/medium3.png" class="product" alt="medium3" />
        <fieldset class="rating three">
            <input type="radio" id="star5-2" name="ratingthree" value="5" /><label for="star5-2" title="Szuper"><span>&#9733;</span></label>
            <input type="radio" id="star4-2" name="ratingthree" value="4" /><label for="star4-2" title="Jó"><span>&#9733;</span></label>
            <input type="radio" id="star3-2" name="ratingthree" value="3" /><label for="star3-2" title="Meh"><span>&#9733;</span></label>
            <input type="radio" id="star2-2" name="ratingthree" value="2" /><label for="star2-2" title="Rossz"><span>&#9733;</span></label>
            <input type="radio" id="star1-2" name="ratingthree" value="1" /><label for="star1-2" title="Borzalmas"><span>&#9733;</span></label>
        </fieldset>
    </div>
    <div class="sidebar-right sidebar">
        <p></p>
    </div>
</div>

<div class="footer">
    <div class="fTable">
        <div class="fRow">
            <img width="90" src="img/cats.png" class="logo" alt="logo" />
        </div>
        <div class="fRow">
            <div class="fCell">
                <h4>A cégről</h4>
                <section><p>tel.: 06701234567</p><p>1088, Budapest, utca 18.</p>
                    <p>faller.daniel3@gmail.com</p></section>
            </div>
            <div class="fCell">
                <h4>Nyitvatartás:</h4>
                <section>
                    <p>h:10-14</p>
                    <p>k:10-14</p>
                    <p>sz:10-14</p>
                    <p>cs:10-14</p>
                </section>
            </div>
            <div class="fCell">
                <h4>Iratkozz fel most</h4>
                <section><p>Feliratkozom a hírlevélre (am ez is lehet link akar)</p></section>
            </div>
        </div>
    </div>

</div>


</body>
</html>