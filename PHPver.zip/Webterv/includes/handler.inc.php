<?php

$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dbname = "loginsys";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dbname);

if(!$conn){
    die("connection failed: ".mysqli_connect_error());
}
