<?php
    $currentPage = 'login';
    require 'header.php';
?>
    <div class="row">
        <div class="sidebar-left sidebar">
            <p></p>
        </div>
        <div class="main">

                <?php
                if(isset($_SESSION['userid'])){
                    echo '<form action="includes/logout.in.php" method="post">
                        <button type="submit" class="regbtn">Kijelentkezés</button>
                        </form>';
                }
                else {
                    echo '<form action="includes/login.inc.php" method="post">
                <div class="container">
                    <h1>Bejelentkezés</h1>
                    <hr>
                    <label for="email"><b>Email/Felhasználónév</b></label>
                    <input type="text" name="email" placeholder="Email" id="email" required>
                    <label for="psw"><b>Jelszó</b></label>
                    <input type="password" name="psw" placeholder="Jelszó" id="psw" required>

                    <hr>

                    <button type="submit" class="regbtn">Bejelentkezés</button>
                </div>

            </form>';
                }
                ?>



        </div>
        <div class="sidebar-right sidebar">
            <p></p>
        </div>
    </div>

    <footer class="footer">
        <div>
        <div class="fTable">
            <div class="fRow">
                <img width="90" src="img/cats.png" class="logo" alt="logo" />
            </div>
            <div class="fRow">
                <div class="fCell">
                    <h4>A cégről</h4>
                    <section><p>tel.: 06701234567</p><p>1088, Budapest, utca 18.</p>
                    <p>faller.daniel3@gmail.com</p></section>
                </div>
                <div class="fCell">
                    <h4>Nyitvatartás:</h4>
                    <section>
                        <p>h:10-14</p>
                        <p>k:10-14</p>
                        <p>sz:10-14</p>
                        <p>cs:10-14</p>
                    </section>
                </div>
                <div class="fCell">
                    <h4>Iratkozz fel most</h4>
                    <section><p>Feliratkozom a hírlevélre (am ez is lehet link akar)</p></section>
                </div>
            </div>
        </div>
        </div>
    </footer>


</body>
</html>